#!/bin/bash

rm archive.zip
zip -r -X archive.zip *
